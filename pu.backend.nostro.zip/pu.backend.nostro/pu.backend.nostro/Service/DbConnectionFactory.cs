﻿using Npgsql;
using pu.backend.nostro.Service.IService;
using System.Data;

namespace pu.backend.nostro.Service
{
    public class DbConnectionFactory: IDbConnectionFactory
    {
        private readonly IConfiguration _configuration;
        public DbConnectionFactory(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IDbConnection CreateConnection()
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            return new NpgsqlConnection(connectionString);
        }
    }
}
