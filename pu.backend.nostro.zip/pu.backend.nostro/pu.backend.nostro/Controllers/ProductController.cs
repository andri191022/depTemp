﻿using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using pu.backend.nostro.Service.IService;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace pu.backend.nostro.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]/[action]")]

    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        // GET: api/<ProductController>
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                if (_productService == null)
                {
                    return NotFound("Product service is not available.");
                }
                else
                {
                    var products = await _productService.GetAllProductsAsync();
                    return Ok(products);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
