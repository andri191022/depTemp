﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace pu.backend.collection.Controller
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ResendController : ControllerBase
    {
    }
}
