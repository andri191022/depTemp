﻿using System.Data;

namespace pu.backend.nostro.Service.IService
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection();
    }
}
