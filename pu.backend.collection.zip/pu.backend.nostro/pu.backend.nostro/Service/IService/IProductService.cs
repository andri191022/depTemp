﻿using pu.backend.nostro.Model.Dto;

namespace pu.backend.nostro.Service.IService
{
    public interface IProductService
    {
        public Task<IEnumerable<t_Products>> GetAllProductsAsync();
    }
}
