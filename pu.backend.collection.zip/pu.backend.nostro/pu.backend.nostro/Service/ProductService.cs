﻿using Dapper;
using pu.backend.nostro.Model.Dto;
using pu.backend.nostro.Service.IService;

namespace pu.backend.nostro.Service
{
    public class ProductService : IProductService
    {
        private readonly IDbConnectionFactory _dbConnectionFactory;
        public ProductService(IDbConnectionFactory dbConnectionFactory)
        {
            _dbConnectionFactory = dbConnectionFactory;
        }
        public async Task<IEnumerable<t_Products>> GetAllProductsAsync()
        {
            using var connection = _dbConnectionFactory.CreateConnection();
            var sql = "SELECT * FROM products";
            var products = await connection.QueryAsync<t_Products>(sql);
            return products;
        }
    }
}
