﻿namespace pu.backend.nostro.Model.Dto
{
    public class t_Products
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public DateTime created_at { get; set; }
        public bool is_active { get; set; }
    }
}
