﻿using System.Data;

namespace pu.backend.collection.Service.IService
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection();
    }
}
