﻿using pu.backend.collection.Model.Dto;

namespace pu.backend.collection.Service.IService
{
    public interface IProductService
    {
        public Task<IEnumerable<t_Products>> GetAllProductsAsync();
    }
}
